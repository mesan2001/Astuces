#include <iostream>
#include <array>
#include <string>

/*

// longueur d'une chaine deja connue avec la fonction length() ; 
int position ( std::string  ch , char c)
{
	int i = 0 ; 
	while ( ch[i] != c)
	{
		i ++ ; 
	}
return i ; 
}
// caractere d'une chaine ch à une position donnée connu en faisant  ch[position]

std::string souschaine ( std::string ch , int deb , int nbcar)
{
	std::string s = "" ; 
	for (int i = deb ; i < nbcar ; i ++)
	{
		s+= ch[i] ; 
	}
return s ; 
}

struct noeud {
	char valeur ; 
	noeud * gauche ; 
	noeud * droit ; 
} ; 
using arbre = noeud * ; 

arbre reconstruit ( std::string prefixe , std::string infixe )
{
	unsigned int taille = prefixe.length () ; 
	if ( ( taille != infixe.length() )  || (taille  == 0 ) )
	{
		return nullptr ; 
	}
	else
	{
		arbre A = new noeud ; 
		A -> valeur = prefixe[0] ; 
		int posR = position ( infixe , A -> valeur) ; 	
		int tailleG = posR ; 
		int tailleD = taille - posR -1 ; 
		A -> gauche = reconstruit ( souschaine (prefixe , 1 , tailleG) , souschaine ( infixe,0,tailleG) ) ; 
		A -> droit = reconstruit ( souschaine (prefixe , tailleG+2 , tailleD) , souschaine ( infixe , posR+1 , tailleD) ) ; 
	return A ; 
	}
}

void afficheprefixe ( arbre B )
{
	if ( B != nullptr)
	{
		std::cout << B -> valeur << " - " ; 
		afficheprefixe ( B -> gauche) ; 
		afficheprefixe ( B -> droit ) ; 
	}
}
void afficheinfixe ( arbre B )
{
	if ( B != nullptr)
	{
		afficheinfixe ( B -> gauche) ; 
		std::cout << B -> valeur << " - " ; 
		afficheinfixe (B -> droit ); 
	}
}

void affichepostfixe (arbre B )
{
	if ( B != nullptr)
	{
		affichepostfixe ( B -> gauche) ; 
		affichepostfixe ( B -> droit ) ; 
		std::cout << B -> valeur << " - " ; 
	}
	
}
*/
// creation d'arbre  : 
/*
struct noeud {
	char valeur ; 
	noeud * gauche ; 
	noeud * droit ; 
} ; 

using arbre = noeud * ; 


arbre creer (char e , arbre B , arbre C)
{
	arbre A = new noeud ; 
	A -> valeur = e ; 
	A -> gauche = B ; 
	A -> droit = C ;  
return A ; 
}
void affichepostfixe (arbre B )
{
	if ( B != nullptr)
	{
		affichepostfixe ( B -> gauche) ; 
		affichepostfixe ( B -> droit ) ; 
		std::cout << B -> valeur << " - " ; 
	}
	
}
void afficheprefixe ( arbre B )
{
	if ( B != nullptr)
	{
		std::cout << B -> valeur << " - " ; 
		afficheprefixe ( B -> gauche) ; 
		afficheprefixe ( B -> droit ) ; 
	}
}
void afficheinfixe ( arbre B )
{
	if ( B != nullptr)
	{
		afficheinfixe ( B -> gauche) ; 
		std::cout << B -> valeur << " - " ; 
		afficheinfixe (B -> droit ); 
	}
}
*/
/*
struct noeud {
int val ;
noeud * g ; 
noeud * d; 
} ; 

using arbre = noeud *; 

arbre initialiser ()
{
	arbre a ; 
	a = nullptr ; 
	return a ; 
}

arbre creer ( int d , arbre a , arbre b)
{
	arbre c = new noeud ; 
	c -> val = d ; 
	c -> g = a ;
	c -> d = b ; 
	return c ; 
}
void afficher (arbre a )
{
	if ( a != nullptr )
	{
		afficher  ( a -> g) ; 
		std::cout << a -> val << " ";
		afficher ( a -> d) ; 
	}

}
bool estlocalementcomplet (arbre a)
{
	if (a ==  nullptr)
		return true ; 
	else if ( ( ( a -> g == nullptr) and ( a -> d != nullptr) ) or ( ( a -> g != nullptr) and ( a -> d == nullptr) ) )
		return false ; 
	else return estlocalementcomplet (a -> g) or estlocalementcomplet (a -> g)  ;  
}-1

int poids (arbre a )
{
	if ( a == nullptr )
		return 0 ; 
	else 
		return a -> val + poids (a ->g) + poids( a -> d) ; 
}

bool estequilibre (arbre a)
{
	if (a == nullptr)
		return true ; 
	else 
		return estlocalementcomplet (a) and ( poids (a -> d) == poids ( a -> g) ) ;
}
*/





struct noeud {
	int  valeur ; 
	noeud * gauche ; 
	noeud * droit ; 
} ; 

using arbre = noeud * ; 


void ajouter ( int e , arbre & a)
{
	if ( a == nullptr )
	{
		a = new noeud ; 
		a -> valeur = e ;
		a -> gauche = nullptr ; 
		a -> droit = nullptr ; 
	}
	else if ( e <= a -> valeur )
		ajouter (e,a->gauche) ; 
	else
		ajouter (e,a -> droit) ;
}

void simmuler (arbre & a )
{
	for ( int i = 0 ; i <= 10 ; i ++)
	{
		ajouter (rand()%20,a) ; 
	}
}
int max (int a , int b)
{
	if (a >= b)
		return a ; 
	else return b ; 
}
int hauteur (arbre a)
{
	if (a == nullptr)
		return -1 ; 
	else if (  (a -> gauche == nullptr) && ( a -> droit == nullptr) )
		return 0 ;
	else return 1+max ( hauteur (a -> gauche) , hauteur (a->droit) ) ; 
}

void afficher (arbre a )
{
	if ( a != nullptr)
	{
		afficher ( a -> gauche) ; 
		std::cout << a -> valeur << " "; 
		afficher ( a -> droit ) ; 
		
	}
}

//verifie si un arbre passé en parametre est un arbre binaire de recherche : il faut penser à implémenter l'arbre en question d'une autre facon que celle de l'implementation d'un arbre binaire de recherche sinon la fonction passera à true à chaaqur appel 

bool estabr ( arbre a )
{
	if ( a == nullptr  )
		return true ; 
	else if ( ( a -> g == nullptr ) and ( a -> d == nullptr ) ) 
		return true ; 
		
	else if ( a -> g == nullptr )
		return  ( ( a -> valeur < a -> d -> valeur ) and estabr (a -> d)  )  ; 
	else if ( a -> d == nullptr  )
		return ( ( a -> valeur >= a -> g -> valeur ) and estabr (a -> g) ) ; 
	else 
		return   ( ( a -> valeur >= a -> g -> valeur ) and ( a -> valeur <= a -> d -> valeur )  and estabr ( a -> g)  and estabr ( a-> d) ); 
}
int main()
{
	//arbre B = reconstruit ("LDNWOUREF" , "WNODLERUF" ); 
	//afficheinfixe (B) ; 


/* CREATION D'ARBRE EN MANUEL
	arbre A1 = nullptr , A2 = nullptr  ; 

	arbre A = creer ('A',A1,A) ; 
	arbre C = creer ('C',A1,A) ; 
	arbre G = creer ('G',A,C) ; 
	arbre K = creer ('k',G,A1) ; 
	// seconde version : 
	arbre K = creer ('K',(creer('G' , (creer ('A',A1,A1) ) ,(creer ('C',A1,A1) ) )),A1) ; 
*/

// TEST
/*
arbre a = creer (4,nullptr,nullptr) ; 
arbre b = creer (4,nullptr,nullptr) ; 
arbre c = creer (14,nullptr,nullptr) ; 
arbre d = creer (6,a,b);
arbre e = creer (9,d,c);
arbre f = creer (12,nullptr,nullptr);
arbre g = creer (13,f,f); 
arbre h = creer (16,e,g);
arbre i = creer (20,h,nullptr);  
//afficher (h) ; 
//std::cout << estequilibre (i); 
std::cout << " le poids est " << poids (i -> g) ; 
*/
	srand(time(NULL)) ;
	arbre a = nullptr ; 

	//afficher (a) ; 
	std::cout << std::endl ; 
	

	for ( int i = 0 ; i <= 10 ; i ++)
	{
		simmuler (a ) ; 
		std::cout << "hateur : " << hauteur (a) << std::endl; 
	}
return 0 ; 
}















