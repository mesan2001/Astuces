#include <iostream> 

using element = std::string ; 

struct couple {
	element valeur ; 
	int priorite ; 
}; 

struct noeud{
	couple  c ; 
	noeud * gauche ; 
	noeud * droit ; 
} ; 


using fileprioritaire = noeud * ; 

fileprioritaire creerfpvide ()
{
	fileprioritaire f ; 
	f = nullptr ; 
	return f ; 
}
bool estvide ( fileprioritaire f)
{
	return f == nullptr ; 
}

void vider ( fileprioritaire & f )
{
	if ( f != nullptr )
	{
		vider (f -> gauche) ;
		vider (f -> droit) ;
		delete f ; 
	}
}

void enfiler ( fileprioritaire & f , int p , element v  )
{
	if ( f == nullptr )
	{
		f = new noeud ; 
		f -> c.valeur = v ; 
		f -> c.priorite = p  ; 
		f -> gauche = nullptr ; 
		f -> droit = nullptr ; 
	}
	else if ( f -> c.priorite <= p )
		enfiler ( f -> gauche , p , v ); 
	else 
		enfiler (f->droit, p , v ); 
}

void afficherqt ( fileprioritaire f)
{
	if ( f == nullptr )
	{
		afficherqt (f -> gauche);
		std::cout << f -> c.valeur << " " ; 
		afficherqt ( f -> droit ); 
	}
}
void affichertq ( fileprioritaire f)
{
	if ( f == nullptr )
	{
		affichertq ( f -> droit );
		std::cout << f -> c.valeur << " " ;
		affichertq (f -> gauche);
		 
	}
}
element tete (fileprioritaire f)
{
	if ( f == nullptr )
		return "ERREUR" ; 
	else 
	{
		noeud * tmp = f ; 
		while ( tmp -> droit != nullptr )
		{
			tmp = tmp -> droit ; 
		}
		return tmp -> c.valeur ; 
	}
}

void defiler ( fileprioritaire & f )
{
	if ( f != nullptr )
	{
		if ( ( f -> gauche == nullptr ) and ( f -> droit == nullptr )  )
			delete f ; 
		else if ( f -> gauche == nullptr )
		{
			noeud * tmp = f ; 
			f = f -> droit  ;
			delete tmp ; 
		}
		else if ( f -> droit == nullptr )
		{
			noeud * tmp = f ; 
			f = f -> gauche  ;
			delete tmp ; 
			
		}
		else 
		{
			noeud * tmp = f -> gauche ; 
			while ( tmp  -> droit != nullptr )
			{
				tmp = tmp -> droit ; 
			}
			f -> c.valeur = tmp  -> c.valeur ; 
			defiler ( f -> gauche , tmp -> c.valeur) ;//ici
		}		
	} 
}


// programme principale  : 
int max ( int a , int b)
{
	if ( a >= b)
		return a ; 
	else
		return b ; 
}

int hauteur (fileprioritaire f )
{
	if ( f == nullptr )
		return -1 ; 
	else 
		return 1 + max ( f -> gauche , f -> droit )  ; 	
}

int facteurequilibrage (fileprioritaire f)
{
	if ( ( f != nullptr) and ( f -> gauche != nullptr ) and ( f -> droit != nullptr ) )
	{
		return f -> droit -> c.priorite - f -> gauche ->c.priorite ;  
	}
}


void affichequilibrage ( fileprioritaire f )
{
	if ( f != nullptr)
	{
		std::cout << f -> c.valeur << " : " << facteurequilibrage (f) ; 
		affichequilibrage ( f -> gauche ) ; 
		affichequilibrage ( f -> droit ) ;
	}	
}



//////////////////////


			// 4 - REPRENSENTATION CHAINÉE 				

	struct maillon{
	couple prioriteval ; 
	maillon * suiv ; 
	}; 

using fileprioritairechaine = maillon * ; 

fileprioritairechaine  creer ( )
{
	fileprioritairechaine  ;
	f = nullptr ; 
	return f ; 
}

bool estvide (fileprioritairechaine f )
{
	return f == nullptr ;  
}

void ajouter ( fileprioritairechaine & f ,  int p , element v  )
{
	
	if ( f== nullptr )
	{
		f = new maillon ; 
		f -> prioriteval.valeur = v ; 
		f -> prioritaire.priorite = p ; 
		f -> suiv = nullptr ; 
	}
	else
	{
		tmp = f ; 
		while ( f -> suiv != nullptr ) and ( tmp -> prioriteval.priorite < tmp -> suiv -> prioriteval.priorite )
		{
			tmp = tmp -> suiv ; 
		}
		maillon * aux = new maillon ; 
		aux -> prioriteval.valeur = v ; 
		aux -> prioriteval.priorite = p ; 
		aux -> suiv = tmp -> suiv ; 
		tmp -> suv = aux ; 
	}
}

void supprimer (fileprioritairechaine & f )
{
	if ( f != nullptr )
	{
		std::cout << f -> prioriteval.valeur ; 
		f = f -> suiv ; 
		supprimer (f-> suiv) ; 
	}
}









int main ()
{

	file f = creer () ;  
	enfiler ( f, 2 , A); 
	std::cout << f -> valeur  ; 
	enfiler ( f, 1 , B);
	std::cout << f -> valeur  ; 
	enfiler ( f, 3 , C);
	std::cout << f -> valeur  ; 
	enfiler ( f, 2 , D);
	std::cout << f -> valeur  ; 
	enfiler ( f, 2 , E);
	std::cout << f -> valeur  ; 
	enfiler ( f, 3 , F);
	std::cout << f -> valeur  ; 
	std::cout << std::endl ; 
	afficherqt (f); 
	std::cout << std::endl ; 
	affichertq (f); 
	
	defiler (f) ; 
	std::cout << f -> valeur ; 
	defiler (f) ; 
	std::cout << f -> valeur ;
	defiler (f) ; 
	std::cout << f -> valeur ;
	defiler (f) ; 
	std::cout << f -> valeur ;
	defiler (f) ; 
	std::cout << f -> valeur ;
	defiler (f) ; 
	std::cout << f -> valeur ;
	///////////////////////
	
	
	
	
	fileprioritairechaine f =  creer ( ) ; 
	
	
	
	enfiler ( f, 2 , A); 

	enfiler ( f, 1 , B);

	enfiler ( f, 3 , C);

	enfiler ( f, 2 , D);

	enfiler ( f, 2 , E);

	enfiler ( f, 3 , F);

	
	
	
	supprimer ( f ) ; 
	

	
	return 0 ; 
} 
