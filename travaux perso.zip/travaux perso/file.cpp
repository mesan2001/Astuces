#include <iostream>

struct maillon 
{
	int valeur ; 
	maillon * suiv ; 
} ; 

struct file
{
	maillon * tete ; 
	maillon * queue ; 
} ; 

void intialiser (file & f)
{
	f.tete = nullptr ; 
	f.queue = nullptr ; 
}

void ajouter (int e , file & f )
{
	
	maillon * aux = new maillon ;
	aux -> valeur = e  ; 
	aux -> suiv = nullptr ; 
	if ( f.tete == nullptr )
	{
		f.tete = aux ;   
		f.queue = aux  ; 
	}
	else
	{
		f.queue -> suiv = aux ; 
		f.queue = f.queue -> suiv ; 
	} 
}

void afficher (file f , maillon * t)
{
	if ( t != nullptr)
	{
		std::cout << t -> valeur << " " ; 
		 t = t -> suiv  ; 
		afficher (f,t) ;
	}
}

void afficher (file f)
{
	afficher (f,f.tete ) ; 
}

void afficher_it (file f)
{
	while (f.tete != nullptr)
	{
		std::cout << f.tete -> valeur << " " ; 
		f.tete = f.tete -> suiv; 
	}
}
int main ()
{

	file f ; 
	intialiser (f);
	ajouter (1,f) ;  
	ajouter (2,f); 
	afficher_it (f);
return 0 ; 
}
