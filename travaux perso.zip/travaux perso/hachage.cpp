#include <iostream>




				/************************************************************************************
				*										    *
				*										    *
				*		METHODE DE COLISION : CHAINAGE COALESCENT			    *
				*										    *
				*										    *
				*										    *
				*************************************************************************************/


/*
using element = int ; 

struct alveole {
	element valeur ; 
	bool occupe ;
	int suiv ; 
} ; 

struct tablehachage {
	alveole * t ; 
	int m ; 
	int poslibre ; 
} ; 

void initialiser ( tablehachage & h , int m )
{
	h.t = new alveole [ m ] ; 
	h.m = m ; 
	h.poslibre = m-1 ;
	for ( int i = 0 ; i < m ; i ++ )
	{
		h.t[i].occupe = false ; 
		h.t[i].suiv = -1 ; 
	} 
}

void ajouter ( element e , tablehachage & h) // methode de colision : chainage séparé
{
	// ici definir la fonction : nous prenons l'exemple du td : h(i) = i mod 11
	int i = e % 11 ; 
	if (h.t[i] .occupe)
	{
		while ( h.t[i].suiv >= 0 ) // ici je retrouve le suivant libre 
		{
			i = h.t[i].suiv ; 
		}
		h.t[i].suiv = h.poslibre ; // je trouve le suivant et je lui dit que desormais tu as un suivant et se trouve à la case numero h.poslibre 
		h.t[h.poslibre].valeur = e ; // je vais dans la derniere case libre et je lui file la valeur 
		h.t[h.poslibre].occupe = true ; 
		do
		{
			-- h.poslibre  ; // je mets à jour la derniere position libre dans le tableau
		}
		while ( ( h.poslibre >= 0 ) and ( h.t[h.poslibre].occupe) )  ;
		
	}
	else
	{
		h.t[i].valeur = e ; 
		h.t[i].occupe = true ; 
	}
	
}

*/

				/************************************************************************************
				*										    *
				*										    *
				*		METHODE DE COLISION : CHAINAGE SEPARÉ				    *
				*										    *
				*										    *
				*										    *
				*************************************************************************************/


using element = int ; 

struct maillon{
	element valeur ; 
	maillon * suiv ; 
} ;

using liste = maillon * ; 

struct tablehachage {
	liste * t ; 
	int m ; 
} ; 

void initialiser ( tablehachage & h , int m)
{
	h.t = new liste [m] ; 
	h.m = m ; 
	for ( int i = 0 ; i < m ; i++ )
	{
		h.t[i] = nullptr ; 
	}
}

void ajoutdebut ( element e ,  liste & l )
{
	maillon * aux = new maillon ; 
	aux -> valeur = e ; 
	aux -> suiv = l ;
	l = aux ; 
}

void ajoute ( element e , tablehachage & h )
{
	// ici definir la fonction : nous prenons l'exemple du td : h(i) = i mod 11
	int i = e % 11 ; 
	ajoutdebut (e,h.t[i] ) ; 
}

void afficher (liste l)
{
	if ( l != nullptr)
	{
		std::cout << l -> valeur << " "  ; 
		afficher ( l -> suiv ) ; 
	}
}

void afficher ( tablehachage h )
{
	for ( int i = 0 ; i < h.m ; i++)
	{
		afficher(h.t[i]) ; 
		std::cout << std::endl ; 
	}
}
int main ()
{
	tablehachage h ;
	initialiser (h,11) ;
	//ajouter (5,h) ;  
	//ajouter (5,h) ; 
	

	ajoute (2,h) ; 
	ajoute (2,h) ; 
	afficher (h) ; 

	return 0 ; 
}
