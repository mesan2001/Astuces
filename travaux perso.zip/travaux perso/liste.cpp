#include <iostream>
#include <string>
#include <cstdlib> 
using element = int ; 
struct maillon{
	element valeur ; 
	maillon * suiv ; 
} ; 

using liste = maillon * ; 

liste initialiser ()
{
	liste A ; 
	A = nullptr ; 
	return A ; 
}
void ajoutdebut ( element e ,liste & l )
{
	maillon * aux = l ; 
	l = new maillon ; 
	l -> valeur = e ; 
	l -> suiv = aux ; 
}
	
void ajoutfin_iteratif ( element e , liste & l)
{	// si je me pointe vers toi , mon suivant c'est ton suivant.
	maillon * aux = new maillon ; 
	aux -> valeur = e; 
	aux -> suiv = nullptr ; 
	if ( l == nullptr)
	{
		l = aux ; 
	}
	else
	{
		maillon * tmp = l ; 
		while ( tmp -> suiv != nullptr)
		{
			tmp = tmp -> suiv ; 
		}
		tmp -> suiv = aux ;
	}
}	

void ajoutfin_recursif ( element e , liste & l)
{
	if ( l == nullptr)
	{
		maillon * aux = new maillon ; 
		aux -> valeur = e; 
		aux -> suiv = nullptr ;
		l = aux ; 
	}
	else
	{
		ajoutfin_recursif (e,l->suiv) ; 
	}
}

bool ajoutposition_recursif ( element e , int position , liste & l)
{
	if ( ( position < 1) or ( ( l == nullptr) and ( position > 1) ) ) // ma condition d'arrete c'est lorsque j'arrive à la fin de la liste et la position est toujours > 1
			return false ; 
	if (position == 1)
	{
		maillon * aux = new maillon ; 
		aux -> valeur = e; 
		aux -> suiv = l ;
		l = aux ; 
		return true ; 
	}
	ajoutposition_recursif (e,position-1,l->suiv) ; 
return false ; // or return false , peu importe . de toute facon , on en arrivera pas là 
}

bool ajoutposition_iteratif (element e , int position , liste & l )
{
		if ( ( position < 1) or ( ( l == nullptr) and ( position > 1) ) )
			return false ; 
		
		maillon * aux = new maillon ; 
		aux -> valeur = e; 

		if ( position == 1) 
		{
			aux -> suiv = l ; 
			l = aux ; 
			return true ; 
		}
		else
		{
			maillon * tmp =  l ; 
			int i = 0 ; 
			while ( ( tmp -> suiv  != nullptr) && ( i < position -2 ) )
			{
				i++ ; 
				tmp = tmp -> suiv ; 
			}
			if ( i ==  position-2 )
			{
				aux -> suiv  = tmp -> suiv ; 
				tmp -> suiv = aux ; 
				return true ;  
			}
		}
return false ; 		
}
void ajouttrie_recursif ( element e , liste & l)  // cette fois-ci , je veux ajouter un element dans une liste triée : 
{

	
	
	if ( ( l == nullptr ) || ( e <= l -> valeur ) )
	{
		maillon * aux = new maillon ; 
		aux -> valeur = e ; 
		aux -> suiv = l ; 
		l = aux ; 		
	}
	else
	{
		ajouttrie_recursif (e,l->suiv) ; 
	}
}

bool esttrie ( liste l)
{
	if ( ( l == nullptr) || ( l -> suiv == nullptr) ) 
		return true ; 
	else
	{
		maillon * tmp = l ; 
		while ( ( tmp -> suiv != nullptr) && ( tmp -> valeur < tmp -> suiv -> valeur ) )
		{
			tmp = tmp -> suiv ; 
		}
		if ( tmp -> suiv != nullptr)
		return false ;
	}
return true ; 
}

void echange ( maillon * a , maillon * b )
{
	maillon * c = a ; 
	a = b ; 
	b = c ; 
}

void trie ( liste & l)
{
	if ( ( l != nullptr ) && ( l -> suiv != nullptr) ) 
	{
		maillon * tmp ; 
		while ( ! esttrie (l) )
		{
			if ( l -> valeur > l -> suiv -> valeur )
			{
				maillon * aux = l ; 
				l = l -> suiv ; 
				aux -> suiv = l -> suiv ; 
				l -> suiv = aux ; 
				
			}
			tmp = l ; 
			while ( tmp -> suiv -> suiv != nullptr)
			{
				if ( tmp -> suiv -> valeur > tmp -> suiv -> suiv -> valeur )
				{
					//echange ( tmp -> suiv , tmp -> suiv -> suiv ) ;  
					maillon * aux = tmp -> suiv 
					
				}
			tmp = tmp -> suiv ; 
			}
		}		
	}
}		
void afficher_recursif (liste l)
{
	if ( l != nullptr)
	{
		std::cout << l-> valeur << " "; 
		afficher_recursif ( l -> suiv) ; 
	}	
}

void afficher_iterarif ( liste l)
{
	maillon * tmp = l  ; 
	while ( tmp != nullptr)
	{
		std::cout << tmp -> valeur << " "; 
		tmp = tmp -> suiv ; 
	}


}

//////////////////////////////////////////////
int main ()
{	
	
	liste l ;
	l = initialiser () ;  
	ajoutdebut (1,l) ; 
	ajoutdebut (2,l) ; 
	ajoutdebut (3,l) ; 
	trie (l) ; 
	afficher_iterarif ( l) ; 
		
return 0 ; 
}

